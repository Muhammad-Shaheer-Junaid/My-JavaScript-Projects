// Constructor function to create a Person object
function Person(name, gender, address, education, profession) {
    this.name = name;
    this.gender = gender;
    this.address = address;
    this.education = education;
    this.profession = profession;
  }
  
  // Function to save the record to localStorage
  function saveRecord(person) {
    // Get the existing records from localStorage or initialize as an empty array
    let records = JSON.parse(localStorage.getItem('populationRecords')) || [];
  
    // Push the new record
    records.push(person);
  
    // Save the updated records back to localStorage
    localStorage.setItem('populationRecords', JSON.stringify(records));
  }
  
  // Function to display records from localStorage
  function displayRecords() {
    const recordList = document.getElementById('recordList');
    recordList.innerHTML = ''; // Clear the list before displaying updated records
  
    // Get records from localStorage
    const records = JSON.parse(localStorage.getItem('populationRecords')) || [];
  
    // Loop through the records and display them
    records.forEach((record) => {
      const li = document.createElement('li');
      li.textContent = `Name: ${record.name}, Gender: ${record.gender}, Address: ${record.address}, Education: ${record.education}, Profession: ${record.profession}`;
      recordList.appendChild(li);
    });
  }
  
  // Event listener for the form submission
  document.getElementById('personForm').addEventListener('submit', function (event) {
    event.preventDefault();
  
    // Get values from the form
    const name = document.getElementById('name').value;
    const gender = document.querySelector('input[name="gender"]:checked') ? document.querySelector('input[name="gender"]:checked').value : '';
    const address = document.getElementById('address').value;
    const education = document.getElementById('education').value;
    const profession = document.getElementById('profession').value;
  
    // Create a new Person object
    const person = new Person(name, gender, address, education, profession);
  
    // Save the person record to localStorage
    saveRecord(person);
  
    // Display all records
    displayRecords();
  
    // Clear the form
    document.getElementById('personForm').reset();
  });
  
  // Display the saved records when the page loads
  window.onload = displayRecords;
  